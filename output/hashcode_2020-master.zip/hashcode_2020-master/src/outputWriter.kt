import java.io.File

fun writeOutput(data: List<String>) {
  File("./output/${fileName}.out").writeText(data.joinToString("\n"))
}
