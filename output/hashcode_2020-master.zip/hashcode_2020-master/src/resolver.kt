const val fileName = "a_example"

fun resolve(input: List<String>): List<String> {
  return emptyList()
}