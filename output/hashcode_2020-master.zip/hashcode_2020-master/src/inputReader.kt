import java.io.File

fun readInput(): List<String> = File("./input/${fileName}.in").readLines()